import {Component, OnInit} from '@angular/core';
import {timeout} from "rxjs/operators";
import set = Reflect.set;
import {AppareilService} from "./service/appareil.service";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  constructor()
  {

  }
}


