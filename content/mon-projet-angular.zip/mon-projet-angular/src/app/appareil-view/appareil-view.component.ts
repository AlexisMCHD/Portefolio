import { Component, OnInit } from '@angular/core';
import {AppareilService} from "../service/appareil.service";

@Component({
  selector: 'app-appareil-view',
  templateUrl: './appareil-view.component.html',
  styleUrls: ['./appareil-view.component.scss']
})
export class AppareilViewComponent implements OnInit {
  isAuth = false;

  lastUpdate = new Promise(
    (resolve, reject) => {
      const date = new Date();
      setTimeout(
        () => {
          resolve(date);
        },
      );
    }
  )

  appareils: any [];

  constructor(private AppareilSerice: AppareilService) {
    setTimeout(
      () => {
        this.isAuth = true;
      }, 4000
    );
  }
  ngOnInit(){
    this.appareils = this.AppareilSerice.appareils;
  }
  onAlumer() {
    this.AppareilSerice.switchOffAll();
  }
  onEteindre(){
    this.AppareilSerice.switchOnAll();
  }

}
