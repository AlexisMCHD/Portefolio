def test(lettre,ch):
    if lettre in ch :
        return True
    else :
        return False
    
print(test("h","maison rouge"))