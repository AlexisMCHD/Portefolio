resultat=" "
n =int(input("saisir un nombre : "))
def estPaire (n):
    if (n % 2 == 0) :
        print("le nombre "+ str(n) + " est pair")
    else :
        print("le nombre "+ str(n) + "est impaire")
estPaire(n)