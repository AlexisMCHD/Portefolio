def listeLettres(val):
    liste=[]
    for i in range (len(val)):
        liste+=val[i]
    print("les lettres sont : "+", ".join(liste)+".")
listeLettres("chapeau")



 



