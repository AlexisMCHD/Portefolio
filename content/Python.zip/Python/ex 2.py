def ordo(suite):
    tab = suite.split()
    tab.sort()
    return(' et '.join(tab))

print(ordo("k f"))