def ordo(suite):
    tab = suite.split()
    tab.sort()
    print(' et '.join(tab))
ordo("g d")
    
         