def divisible(nombres1,nombres2):
    if (nombres2%nombres1==0):
        return True
    else:
        return False
print(divisible(4,17))
    