def listeLettres(val):
    liste=[]
    for i in range (len(val)):
        liste+=val[i]
    return("les lettres sont : "+", ".join(liste)+".")

print(listeLettres("maison"))