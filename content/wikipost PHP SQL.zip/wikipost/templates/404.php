<!-- include le head et le header... -->
<?php include("top.php") ?>

<!-- contenu spécifique à cette page -->
<h2>Damnnnnn 404</h2>
<div>owww shit</div>

<!-- inclue le footer et les fermetures de balises -->
<?php include("bottom.php") ?>
