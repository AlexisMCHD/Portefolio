<!-- include le head et le header... -->
<?php include("top.php") ?>

<!-- contenu spécifique à cette page -->
<h2>Conditions d'Utilisation</h2>
<p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dicta fugiat nam laudantium ipsum illum quam quasi necessitatibus doloremque perspiciatis voluptatum ea iusto temporibus ex eum et, in id aperiam saepe.e</p>

<p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Voluptates, nemo! Ipsa aspernatur eius eum quae dolorem. Illum autem saepe quaerat aperiam, cumque ipsa rerum facilis quo corrupti, atque eveniet velit?</p>

<!-- inclue le footer et les fermetures de balises -->
<?php include("bottom.php") ?>
