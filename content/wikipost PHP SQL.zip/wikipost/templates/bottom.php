        </main>
        <footer class="mt-3 mb-3 text-center">
            &copy; <?= date("Y") ?> Wikipost
        </footer>
    </div> <!-- ferme la div class container -->
</body>
</html>