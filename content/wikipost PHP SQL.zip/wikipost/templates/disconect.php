<!-- include le head et le header... -->
<?php include("top.php") ?>

<!-- contenu spécifique à cette page -->
<h2>Déconnexion !</h2>

<!-- inclue le footer et les fermetures de balises -->
<?php include("bottom.php") ?>