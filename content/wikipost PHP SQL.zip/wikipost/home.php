<!-- include le head et le header... -->
<?php include("top.php") ?>

<!-- contenu spécifique à cette page -->
<h2>Bievenue sur Wikipost</h2>
<p>Ce site présente les meilleurs articles bla bla bla...</p>

<!-- inclue le footer et les fermetures de balises -->
<?php include("bottom.php") ?>




